create
    definer = root@localhost procedure update_store_age_warning_record()
BEGIN
    DECLARE v_goods_id BIGINT;
    DECLARE v_in_date DATE;
    DECLARE v_current_date DATE;
    DECLARE v_warning_id BIGINT;
    DECLARE v_warning_type TINYINT;
    DECLARE v_position_id BIGINT;
    DECLARE v_warning_store_age INT;
    DECLARE v_store_age_existed INT;
    DECLARE v_warning_existed INT;
    DECLARE v_extra_time INT;
    DECLARE v_num INT;

-- 获取当前日期
SET v_current_date = DATE(NOW());
-- 查询所有超龄货物
SELECT position_id, goods_type, in_date, id, store_age, goods_num 
INTO v_position_id, v_goods_id, v_in_date, v_warning_id, v_warning_store_age, v_num
FROM position
JOIN warning ON position.goods_type = warning.goods_id
WHERE DATE_ADD(in_date, INTERVAL warning.store_age DAY) < v_current_date
AND warning.type = 3
AND position.state = 1;

SELECT CONCAT('v_warning_store_age：', v_warning_store_age) AS '提示信息';
IF v_warning_store_age IS NOT NULL THEN
    -- 查询store_age_record表中是否已存在该预警记录
    SELECT COUNT(*) INTO v_store_age_existed
    FROM warning_record
    WHERE state = 0
    AND warning_id = v_warning_id
    AND position_id = v_position_id
		AND type = 5;
    
    -- 如果不存在库龄预警记录，则创建新的预警记录
    IF v_store_age_existed = 0 THEN
        SET v_warning_type = 5;
        -- 创建预警记录
        INSERT INTO warning_record (warning_id, time, type, position_id, goods_id, num)
        VALUES (v_warning_id, v_current_date, v_warning_type, v_position_id, v_goods_id, v_num);
    END IF;
    
    -- 更新预警记录的extraTime字段
    SELECT DATEDIFF(v_current_date, DATE_ADD(v_in_date, INTERVAL v_warning_store_age DAY)) + 1 INTO v_extra_time;
    UPDATE warning_record
    SET extra_time = v_extra_time, time = v_current_date
    WHERE state = 0
    AND warning_id = v_warning_id
    AND position_id = v_position_id
		AND type = 5;
		
END IF;
END;

