create definer = root@localhost trigger trigger_warning_record_update
    before update
    on warning_record
    for each row
BEGIN
    DECLARE max_num FLOAT;
    DECLARE min_num FLOAT;
    SELECT max, min INTO max_num, min_num FROM warning WHERE id = NEW.warning_id AND type = 1;
    IF NEW.state = 0 AND NEW.type = 1 AND max_num IS NOT NULL AND NEW.num < max_num THEN
        SET NEW.state = 1;
    ELSEIF NEW.state = 0 AND NEW.type = 2 AND min_num IS NOT NULL AND NEW.num > min_num THEN
        SET NEW.state = 1;
    END IF;
END;

