create
    definer = root@localhost procedure update_warning_record()
BEGIN
    DECLARE v_goods_id BIGINT;
    DECLARE v_expiration_date DATE;
    DECLARE v_current_date DATE;
    DECLARE v_warning_id BIGINT;
    DECLARE v_warning_type TINYINT;
    DECLARE v_position_id BIGINT;
    DECLARE v_warning_expiration INT;
    DECLARE v_expiration_existed INT;
    DECLARE v_warning_existed INT;
		DECLARE v_num INT;
		
    -- 获取当前日期
    SET v_current_date = DATE(NOW());
    -- 查询仓库内所有过期或将要过期的货物
    SELECT position_id, goods_type, expiration_date, id, expiration, goods_num 
    INTO v_position_id, v_goods_id, v_expiration_date, v_warning_id, v_warning_expiration, v_num
    FROM position
    JOIN warning ON position.goods_type = warning.goods_id
    WHERE DATE(expiration_date) <= DATE_ADD(v_current_date, INTERVAL warning.expiration DAY)
    AND warning.type = 2
		AND position.state = 1;
		
    IF v_warning_expiration IS NOT NULL THEN
        -- 查询warning_record表中是否已存在该预警记录
        SELECT COUNT(*) INTO v_warning_existed
        FROM warning_record
        WHERE state = 0
        AND warning_id = v_warning_id
        AND position_id = v_position_id
				AND type IN (3,4);
        -- 如果不存在预警记录，则创建新的预警记录
        IF v_warning_existed = 0 THEN
            -- 判断预警类型
            IF v_expiration_date < v_current_date THEN
                    SET v_warning_type = 4;
            ELSE
                    SET v_warning_type = 3;
            END IF;
            -- 创建预警记录
            INSERT INTO warning_record (warning_id, time, type, position_id, goods_id, num)
            VALUES (v_warning_id, v_current_date, v_warning_type, v_position_id, v_goods_id, v_num);
        END IF;
        -- 更新预警记录的extraTime字段
        UPDATE warning_record
        SET extra_time = ABS(DATEDIFF(v_expiration_date, v_current_date)), time = v_current_date
        WHERE state = 0
        AND warning_id = v_warning_id
        AND position_id = v_position_id
				AND type IN (3,4);
		
    END IF;
END;

