create definer = root@localhost trigger update_warning_record_state
    before update
    on warning_record
    for each row
BEGIN
    IF NEW.type = 3 AND NEW.extra_time < 0 THEN
        SET NEW.state = 1;
    END IF;
END;

