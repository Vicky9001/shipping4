create definer = root@localhost trigger trg_warning_insert
    after insert
    on warning
    for each row
BEGIN
  DECLARE max_num FLOAT;
  DECLARE min_num FLOAT;
  SELECT `max`, `min` INTO max_num, min_num FROM warning WHERE id = NEW.id;
  IF NEW.type = 1 THEN
    IF (SELECT grounding_num FROM goods WHERE goods_id = NEW.goods_id) > max_num OR (SELECT grounding_num FROM goods WHERE goods_id = NEW.goods_id) < min_num THEN 
      INSERT INTO warning_record (warning_id, time, type, goods_id, num, extra_num)
      VALUES (NEW.id, NOW(), IF((SELECT grounding_num FROM goods WHERE goods_id = NEW.goods_id) > max_num, 1, 2), NEW.goods_id, (SELECT grounding_num FROM goods WHERE goods_id = NEW.goods_id), IF((SELECT grounding_num FROM goods WHERE goods_id = NEW.goods_id) > max_num, (SELECT grounding_num FROM goods WHERE goods_id = NEW.goods_id) - NEW.max, NEW.min - (SELECT grounding_num FROM goods WHERE goods_id = NEW.goods_id)));
    END IF;
  END IF;
END;

