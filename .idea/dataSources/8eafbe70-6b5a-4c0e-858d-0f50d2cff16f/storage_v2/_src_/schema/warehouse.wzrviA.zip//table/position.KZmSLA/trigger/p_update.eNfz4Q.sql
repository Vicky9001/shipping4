create definer = root@localhost trigger p_update
    after update
    on position
    for each row
BEGIN
	update area,
	(select area_id,count(shelve_id) as c from position group by area_id) p
	set area.shelve_num = p.c 
	where area.id = p.area_id;
    
	update goods,
	(select goods_type,sum(goods_num) as s from position group by goods_type) g
	set goods.grounding_num = g.s
	where goods.goods_id = g.goods_type;
END;

