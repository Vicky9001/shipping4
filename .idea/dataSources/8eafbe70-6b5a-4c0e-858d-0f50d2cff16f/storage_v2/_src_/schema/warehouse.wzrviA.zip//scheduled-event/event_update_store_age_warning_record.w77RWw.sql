create definer = root@localhost event event_update_store_age_warning_record on schedule
    every '1' DAY
        starts '2023-04-06 00:00:00'
    enable
    do
    CALL update_store_age_warning_record();

