create definer = root@localhost trigger trigger_warning_record
    after update
    on goods
    for each row
BEGIN
    DECLARE max_num FLOAT;
    DECLARE min_num FLOAT;
    SELECT max, min INTO max_num, min_num FROM warning WHERE goods_id = NEW.goods_id AND type = 1;
    IF EXISTS(SELECT * FROM warning_record WHERE goods_id = NEW.goods_id AND state = 0) THEN
        IF EXISTS(SELECT * FROM warning_record WHERE goods_id = NEW.goods_id AND state = 0 AND type = 1) THEN
            UPDATE warning_record SET extra_num = extra_num - (OLD.grounding_num - NEW.grounding_num), num = NEW.grounding_num WHERE goods_id = NEW.goods_id AND extra_num IS NOT NULL AND state = 0 AND type = 1;
        ELSEIF EXISTS(SELECT * FROM warning_record WHERE goods_id = NEW.goods_id AND state = 0 AND type = 2) THEN
            UPDATE warning_record SET extra_num = extra_num + (OLD.grounding_num - NEW.grounding_num), num = NEW.grounding_num WHERE goods_id = NEW.goods_id AND extra_num IS NOT NULL AND state = 0 AND type = 2;
        END IF;
    ELSE
        IF max_num IS NOT NULL AND NEW.grounding_num > max_num THEN
            INSERT INTO warning_record (warning_id, time, type, goods_id, num, extra_num)
            VALUES ((SELECT id FROM warning WHERE goods_id = NEW.goods_id AND type = 1), NOW(), 1, NEW.goods_id, NEW.grounding_num, NEW.grounding_num - max_num);
        ELSEIF min_num IS NOT NULL AND NEW.grounding_num < min_num THEN
            INSERT INTO warning_record (warning_id, time, type, goods_id, num, extra_num)
            VALUES ((SELECT id FROM warning WHERE goods_id = NEW.goods_id AND type = 1), NOW(), 2, NEW.goods_id, NEW.grounding_num, min_num - NEW.grounding_num);
        END IF;
    END IF;
END;

