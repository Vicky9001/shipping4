create definer = root@localhost trigger update_warning_record_num
    after update
    on position
    for each row
BEGIN
    -- 当position表里的goods_num变化时，更新相应的warning_record
    IF NEW.goods_num != OLD.goods_num THEN
        UPDATE warning_record
        SET num = NEW.goods_num
        WHERE position_id = OLD.position_id
        AND state = 0;
    END IF;
    
    -- 当goods_num=0时，将相应的warning_record的state设置为1
    IF NEW.goods_num = 0 THEN
        UPDATE warning_record
        SET state = 1
        WHERE position_id = OLD.position_id
        AND state = 0;
    END IF;
END;

